#include <iostream>
int main()
  {
  std::cout << "This is the whole thing." << std::endl;
  }
