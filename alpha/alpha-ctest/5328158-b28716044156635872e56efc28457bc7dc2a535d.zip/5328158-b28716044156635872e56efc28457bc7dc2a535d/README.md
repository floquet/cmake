## CTest Example


After you clone this, run the following commands:
* `$ mkdir build && cd build`
* `$ cmake ..`
* `$ make` and observe that the executable is made.
* `$ make test`

**Bonus Points**

1. Make a test that actually does something.
